﻿using System;
using System.IO;
using System.Reflection;

class Program
{
    static void Main()
    {
        Console.WriteLine("Pentz Studios - All Rights Reserved");
        Console.WriteLine("Youtube - @PentzStudio");
        
        // Assuming the file is located in the root directory of the project
        string fileName = "FileChanger.exe";

        // Get the current directory (the directory from where the app is running)
        string currentDirectory = Directory.GetCurrentDirectory();

        // Combine the current directory with the file name
        string fullPath = Path.Combine(currentDirectory, fileName);

        //Console.WriteLine($"Full path of the file: {fullPath}");

        // Use ".." to go up one directory
        string parentPath = Path.Combine(currentDirectory, "../..");

        // Get the full path (normalized)
        string normalizedParentPath = Path.GetFullPath(parentPath);

        Console.WriteLine($"Parent directory: {normalizedParentPath}");

        Console.WriteLine(normalizedParentPath + @"\GameInfoFiles\CS2 GameInfoFile\gameinfo.gi");
        Console.WriteLine(normalizedParentPath + @"\GameInfoFiles\S2FM GameInfoFile\gameinfo.gi");
        Console.Write("\n\n");

        string giFilePath = File.ReadAllText(@normalizedParentPath + @"\GameInfoFiles\PathWhereTheFileNeedsToChange\pfc.txt");

        bool restart = true;

        while (restart == true)
        {
            restart = false;

            Console.WriteLine("CS2 (1) or S2FM (2), if you press enter without input it closes itself.");
            string gameInfoType = Console.ReadLine();

            if (gameInfoType == "")
            {
                
            }
            else if (gameInfoType == "1")
            {
                //CS2 Version of GameInfo.gi
                // Path of the source file you want to use to overwrite
                string sourceFilePath = normalizedParentPath + @"\GameInfoFiles\CS2 GameInfoFile\gameinfo.gi";

                // Path of the destination file that you want to overwrite
                string destinationFilePath = giFilePath;

                try
                {
                    // Copy the source file to the destination path, overwriting the existing file
                    File.Copy(sourceFilePath, destinationFilePath, true);

                    Console.WriteLine($"GameInfo changed to CS2 Mode.");
                    restart = true;
                }
                catch
                {

                }
            }
            else
            {
                //S2FM Version of GameInfo.gi
                // Path of the source file you want to use to overwrite
                string sourceFilePath = normalizedParentPath + @"\GameInfoFiles\S2FM GameInfoFile\gameinfo.gi";

                // Path of the destination file that you want to overwrite
                string destinationFilePath = giFilePath;

                try
                {
                    // Copy the source file to the destination path, overwriting the existing file
                    File.Copy(sourceFilePath, destinationFilePath, true);

                    Console.WriteLine($"GameInfo changed to S2FM Mode.");
                    restart = true;
                }
                catch
                {

                }
            }
        }
    }
}
