﻿using System;
using System.IO;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        Console.WriteLine("Youtube - @PentzStudio\nLink - https://www.youtube.com/@PentzStudio/videos");
        Console.WriteLine("\n\nUser Manual-------------------------------------------------------------");
        Console.WriteLine("\nDo NOT close this exe file, if you close this file you will be unable to play CS2.");
        Console.WriteLine("If you accindetally closed this file run it again and then close the CS2 Workshop Tools and you can play CS2 again.\nIf you are unsure what to do watch the tutorial video above.");

        string fileName = "FileChanger.exe";
        string currentDirectory = Directory.GetCurrentDirectory(); // Get current directory only
        string filePath = Path.Combine(currentDirectory, fileName);

        // Go back two directories
        string mainFolderPath = Path.GetFullPath(Path.Combine(currentDirectory, "..", ".."));
        //Console.WriteLine("Main Folder Path: " + mainFolderPath);

        string mainGameFolderPath = File.ReadAllText(mainFolderPath + @"/GameInfoFiles\PathWhereTheFileNeedsToChange\pfc.txt");
        //Console.WriteLine("Main Game Folder Path: " + mainGameFolderPath);

        string mainGameGameinfogiFile = mainGameFolderPath + @"\game\csgo\gameinfo.gi";
        //Console.WriteLine(mainGameGameinfogiFile);

        if (IsProcessRunning() == true || IsProcess2Running() == true)
        {
            CloseEveryCS("cs2");
            CloseEveryCS("csgocfg");
        }

        File.Copy(mainFolderPath + @"\GameInfoFiles\S2FM GameInfoFile\gameinfo.gi", mainGameGameinfogiFile, true);

        bool started = false;

        Process.Start(mainGameFolderPath + @"\game\bin\win64\csgocfg.exe");

        started = true;

        while (started == true)
        {
            while (IsProcessRunning() == false && IsProcess2Running() == false)
            {
                File.Copy(mainFolderPath + @"\GameInfoFiles\CS2 GameInfoFile\gameinfo.gi", mainGameGameinfogiFile, true);
                Process.GetCurrentProcess().Kill();
            }
        }

        Console.ReadKey();
    }

    static bool IsProcessRunning()
    {
        // Get all processes with the specified name
        Process[] processes = Process.GetProcessesByName("cs2");
        return processes.Length > 0; // Returns true if any processes are found
    }

    static bool IsProcess2Running()
    {
        // Get all processes with the specified name
        Process[] processes = Process.GetProcessesByName("csgocfg");
        return processes.Length > 0; // Returns true if any processes are found
    }

    //Closers
    static bool CloseEveryCS(string processName)
    {
        // Get all processes with the specified name
        Process[] processes = Process.GetProcessesByName(processName);

        if (processes.Length > 0)
        {
            foreach (var process in processes)
            {
                try
                {
                    process.Kill(); // Terminate the process
                    process.WaitForExit(); // Optionally wait for the process to exit
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to close {processName}.exe: {ex.Message}");
                    return false;
                }
            }
            return true;
        }
        return false; // No process found
    }
}
